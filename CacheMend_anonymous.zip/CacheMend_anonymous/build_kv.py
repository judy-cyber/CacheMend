#!/usr/bin/env python3
from run import main

if __name__ == '__main__':
    main(fixed_stage='cache')
